#include "ioctlcmd.h"

//
// �p�X���̍ő�p�X��
//
#define MAXPATHLEN 1024

//
// �쐬����̓V���{���b�N�����N�ɓ��B���Ē�~����
//
#define STATUS_STOPPED_ON_SYMLINK ((NTSTATUS)0x8000002DL)

//
// Documented in the IFS Kit
//
typedef struct _FILE_FS_ATTRIBUTE_INFORMATION {
	ULONG FileSystemAttributes;
	LONG MaximumComponentNameLength;
	ULONG FileSystemNameLength;
	WCHAR FileSystemName[1];
} FILE_FS_ATTRIBUTE_INFORMATION, *PFILE_FS_ATTRIBUTE_INFORMATION;

//
// IFS Kit �Œ�`
//
NTKERNELAPI
NTSTATUS
IoQueryVolumeInformation(
	IN PFILE_OBJECT FileObject,
	IN FS_INFORMATION_CLASS FsInformationClass,
	IN ULONG Length,
	OUT PVOID FsInformation,
	OUT PULONG ReturnedLength
	);

typedef
VOID
(*PDRIVER_FS_NOTIFICATION) (
	IN struct _DEVICE_OBJECT *DeviceObject,
	IN BOOLEAN FsActive
	);

NTKERNELAPI
NTSTATUS
IoRegisterFsRegistrationChange(
	IN PDRIVER_OBJECT DriverObject,
	IN PDRIVER_FS_NOTIFICATION DriverNotificationRoutine
	);

NTKERNELAPI
NTSTATUS
IoUnregisterFsRegistrationChange(
	IN PDRIVER_OBJECT DriverObject,
	IN PDRIVER_FS_NOTIFICATION DriverNotificationRoutine
	);

NTKERNELAPI
NTSTATUS
ObQueryNameString(
	IN PVOID Object,
	OUT POBJECT_NAME_INFORMATION ObjectNameInfo,
	IN ULONG Length,
	OUT PULONG ReturnLength
	);

NTKERNELAPI
BOOLEAN
NTAPI
IoIsSystemThread(
	IN PETHREAD Thread
	);

NTKERNELAPI
PACCESS_TOKEN
PsReferenceImpersonationToken(
	IN PETHREAD Thread,
	OUT PBOOLEAN CopyOnOpen,
	OUT PBOOLEAN EffectiveOnly,
	OUT PSECURITY_IMPERSONATION_LEVEL ImpersonationLevel
	);

#define PsDereferenceImpersonationToken(T)  \
{	if (ARGUMENT_PRESENT(T)) {      \
		(ObDereferenceObject((T))); \
	} else {                        \
		;                           \
	}                               \
}

typedef struct {
	PDEVICE_OBJECT FileSystem;
	POBJECT_NAME_INFORMATION Root;
	BOOLEAN RootChecked;
} HOOK_EXTENSION, *PHOOK_EXTENSION;

//
// ���� I/O �e�[�u���ɓ���̃G���g�������݂��邩�ǂ������ׂ�
//
#define FASTIOPRESENT(_hookExt, _call) \
	(_hookExt != NULL && _hookExt->FileSystem != NULL && \
	 _hookExt->FileSystem->DriverObject->FastIoDispatch && \
	 ((ULONG_PTR)&_hookExt->FileSystem->DriverObject->FastIoDispatch->_call - \
	  (ULONG_PTR)&_hookExt->FileSystem->DriverObject->FastIoDispatch->SizeOfFastIoDispatch < \
	  (ULONG_PTR)_hookExt->FileSystem->DriverObject->FastIoDispatch->SizeOfFastIoDispatch) && \
	 _hookExt->FileSystem->DriverObject->FastIoDispatch->_call)
