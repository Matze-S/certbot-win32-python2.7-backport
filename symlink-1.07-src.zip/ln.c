#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
//
// ln - �n�[�h�����N��W�����N�V�������쐬����
//
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x500
#include <windows.h>
#include <winioctl.h>
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <io.h>
#include <fcntl.h>
#include <tchar.h>
#include "ioctlcmd.h"

#define SE_CREATE_SYMBOLIC_LINK_NAME      TEXT("SeCreateSymbolicLinkPrivilege")

LPCTSTR myname;

static union {
	REPARSE_DATA_BUFFER iobuf;
	TCHAR dummy[MAXIMUM_REPARSE_DATA_BUFFER_SIZE];
} u;

void PrintWin32Error(LPCTSTR message)
{
	DWORD code = GetLastError();
	PVOID pv;

	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_IGNORE_INSERTS |
	              FORMAT_MESSAGE_FROM_SYSTEM, NULL, code,
	              MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
	              (LPTSTR)&pv, 0, NULL);
//	_tprintf(_T("%s (%d): %s"), message, code, pv);
	_tprintf(_T("%s: %s"), message, pv);
	LocalFree(pv);
}

void DumpReparsePointBuf(DWORD cb)
{
	printf("cb = %d\n", cb);
	printf("ReparseTag = %#08x\n", u.iobuf.ReparseTag);
	printf("ReparseDataLength = %d\n", u.iobuf.ReparseDataLength);
	printf("Reserved = %d\n", u.iobuf.Reserved);
	switch (u.iobuf.ReparseTag) {
	case IO_REPARSE_TAG_MOUNT_POINT:
		printf("SubstituteNameOffset = %d\n", u.iobuf.MountPointReparseBuffer.SubstituteNameOffset);
		printf("SubstituteNameLength = %d\n", u.iobuf.MountPointReparseBuffer.SubstituteNameLength);
		printf("%.*S\n",
			u.iobuf.MountPointReparseBuffer.SubstituteNameLength / sizeof(WCHAR),
			u.iobuf.MountPointReparseBuffer.PathBuffer + u.iobuf.MountPointReparseBuffer.SubstituteNameOffset / sizeof(WCHAR));
		printf("PrintNameOffset = %d\n", u.iobuf.MountPointReparseBuffer.PrintNameOffset);
		printf("PrintNameLength = %d\n", u.iobuf.MountPointReparseBuffer.PrintNameLength);
		printf("%.*S\n",
			u.iobuf.MountPointReparseBuffer.PrintNameLength / sizeof(WCHAR),
			u.iobuf.MountPointReparseBuffer.PathBuffer + u.iobuf.MountPointReparseBuffer.PrintNameOffset / sizeof(WCHAR));
		break;
	case IO_REPARSE_TAG_SYMLINK:
		printf("SubstituteNameOffset = %d\n", u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameOffset);
		printf("SubstituteNameLength = %d\n", u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameLength);
		printf("%.*S\n",
			u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameLength / sizeof(WCHAR),
			u.iobuf.SymbolicLinkReparseBuffer.PathBuffer + u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameOffset / sizeof(WCHAR));
		printf("PrintNameOffset = %d\n", u.iobuf.SymbolicLinkReparseBuffer.PrintNameOffset);
		printf("PrintNameLength = %d\n", u.iobuf.SymbolicLinkReparseBuffer.PrintNameLength);
		printf("Flags = %d\n", u.iobuf.SymbolicLinkReparseBuffer.Flags);
		printf("%.*S\n",
			u.iobuf.SymbolicLinkReparseBuffer.PrintNameLength / sizeof(WCHAR),
			u.iobuf.SymbolicLinkReparseBuffer.PathBuffer + u.iobuf.SymbolicLinkReparseBuffer.PrintNameOffset / sizeof(WCHAR));
		break;
	}
}

BOOL AcquireSymlinkPriv()
{
	HANDLE hToken;
	TOKEN_PRIVILEGES TokenPriv;
	BOOL result;

	if (!LookupPrivilegeValue(NULL, SE_CREATE_SYMBOLIC_LINK_NAME, &TokenPriv.Privileges[0].Luid)) {
		//
		// Windows XP�ȑO�ɂ͂��̓����͑��݂��Ȃ��B
		//
		return TRUE;
	}
	TokenPriv.PrivilegeCount = 1;
	TokenPriv.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken)) {
		return FALSE;
	}

	result = AdjustTokenPrivileges(hToken, FALSE, &TokenPriv, 0, NULL, NULL)
		&& GetLastError() == ERROR_SUCCESS;
	CloseHandle(hToken);

	return result;
}

BOOL CreateSymlink(LPCTSTR lpLinkName, LPCTSTR lpTargetName, LPSECURITY_ATTRIBUTES lpsa)
{
	HANDLE hFile;
	TCHAR namebuf[MAX_PATH + 6];
	DWORD cb;
	DWORD attr;
	BOOL isDirectory;
	BOOL (WINAPI *deletefunc)(LPTSTR);
	BOOL isRelative = FALSE;

	attr = GetFileAttributes(lpTargetName);
	if (attr == INVALID_FILE_ATTRIBUTES)
		return FALSE;
	isDirectory = attr & FILE_ATTRIBUTE_DIRECTORY;
	deletefunc = isDirectory ? RemoveDirectory : DeleteFile;

	if (!AcquireSymlinkPriv()) {
		// ignore errors to support Windows 10 RS2 unprivileged create
		//return FALSE;
	}

	if (*lpTargetName == '\\' || isalpha(*lpTargetName) && lpTargetName[1] == ':') {
		BOOL rv;
		//
		// �����N����t���p�X�ɂ���
		//
		_tcscpy(namebuf, _T("\\?\?\\"));
		if (lpTargetName[0] == '\\' && lpTargetName[1] == '\\') {
			//
			// UNC�̏ꍇ�͂���� UNC\ ��t��
			//
			rv = GetFullPathName(lpTargetName, sizeof(namebuf) / sizeof(namebuf[0]) - 6, namebuf + 6, NULL);
			if (!rv) {
				return FALSE;
			}
			_tcsncpy(namebuf + 4, _T("UNC\\"), 4); // \0 �͕t���Ȃ�
		} else {
			rv = GetFullPathName(lpTargetName, sizeof(namebuf) / sizeof(namebuf[0]) - 4, namebuf + 4, NULL);
			if (!rv) {
				return FALSE;
			}
		}
	} else {
		//
		// ���΃p�X�̓t���p�X�����Ȃ�
		// .\ �ƃp�X�̓r���ɂ��� ..\ �͉�������
		// ���̃R�[�h�̓}���`�o�C�g������2�o�C�g�ڂ��l�����Ȃ��̂�
		// WideChar ���ߑł�
		//
		LPCWSTR p = lpTargetName;
		LPWSTR q = namebuf, root = namebuf;
		while (*p) {
			for (;;) {
				if (p[0] == L'.' && p[1] == L'.' && p[2] == L'\\') {
					// �R�s�[���p�X�̐擪���p�X��؂�̒��オ ..\ �̏ꍇ
					if (q > root) {
						// ���� ..\ �����
						p += 3;
						// �R�s�[��̖��������K�w���
						q--;
						while (q > root && q[-1] != '\\')
							q--;
					} else {
						// �R�s�[�悩����]�n���Ȃ��ꍇ��
						// ..\ ���R�s�[����
						// ..\ �͌ォ�� ..\ ���o�����Ă�����Ȃ��悤�ی삷��
						memcpy(q, p, 3 * sizeof(WCHAR));
						q += 3;
						root += 3;
						p += 3;
					}
				} else if (p[0] == L'.' && p[1] == L'\\') {
					// �R�s�[���p�X�̐擪���p�X��؂�̒��オ .\ �̏ꍇ
					// ���� .\ �����
					p += 2;
				} else {
					break;
				}
			}
			// �p�X�̏I�[�����̃p�X��؂�܂ŃR�s�[
			while (*p && (*q++ = *p++) != '\\')
				;
		}
		*q = 0;
		isRelative = TRUE;
	}
//	_tprintf(_T("%s\n"), namebuf);

	//
	// �����N�t�@�C�����쐬
	//
	if (isDirectory) {
		if (!CreateDirectory(lpLinkName, lpsa))
			return FALSE;
		hFile = CreateFile(lpLinkName, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
			OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	} else {
		hFile = CreateFile(lpLinkName, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, lpsa,
			CREATE_NEW, 0, NULL);
	}
	if (hFile == INVALID_HANDLE_VALUE) {
//		_ftprintf(stderr, _T("CreateFile failed (%d)\n"), GetLastError());
		return FALSE;
	}

	//
	// ���p�[�X�f�[�^��ݒ�
	//
	u.iobuf.ReparseTag = IO_REPARSE_TAG_SYMLINK;
	u.iobuf.Reserved = 0;
	// �\�������R�s�[
	u.iobuf.SymbolicLinkReparseBuffer.PrintNameOffset = 0;
	u.iobuf.SymbolicLinkReparseBuffer.PrintNameLength = wcslen(lpTargetName) * sizeof(WCHAR);
	memcpy((char *)u.iobuf.SymbolicLinkReparseBuffer.PathBuffer + u.iobuf.SymbolicLinkReparseBuffer.PrintNameOffset,
		lpTargetName, u.iobuf.SymbolicLinkReparseBuffer.PrintNameLength);
	// �u�������R�s�[
	u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameOffset = u.iobuf.SymbolicLinkReparseBuffer.PrintNameOffset
		+ u.iobuf.SymbolicLinkReparseBuffer.PrintNameLength;
	u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameLength = wcslen(namebuf) * sizeof(WCHAR);
	memcpy((char *)u.iobuf.SymbolicLinkReparseBuffer.PathBuffer + u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameOffset,
		namebuf, u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameLength);
	// ���̑��̏���ݒ�
	u.iobuf.SymbolicLinkReparseBuffer.Flags = isRelative ? 1 : 0;
	u.iobuf.ReparseDataLength =
		12 +
		u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameOffset +
		u.iobuf.SymbolicLinkReparseBuffer.SubstituteNameLength;
	cb = 8 + u.iobuf.ReparseDataLength;
	//DumpReparsePointBuf(cb);
	if (!DeviceIoControl(hFile, FSCTL_SET_REPARSE_POINT,
					&u.iobuf, cb, NULL, 0, &cb, NULL)) {
//		_ftprintf(stderr, _T("DeviceIoControl failed (%d)\n"), GetLastError());
		CloseHandle(hFile);
		deletefunc(lpLinkName);
		return FALSE;
	}

	CloseHandle(hFile);
	return TRUE;
}

BOOL CreateJunction(LPCTSTR lpLinkName, LPCTSTR lpTargetName, LPSECURITY_ATTRIBUTES lpsa)
{
	HANDLE hFile;
	TCHAR namebuf[MAX_PATH + 4];
	DWORD cb;
	DWORD attr;
	BOOL isDirectory;
	BOOL (WINAPI *deletefunc)();

	attr = GetFileAttributes(lpTargetName);
	if (attr == INVALID_FILE_ATTRIBUTES)
		return FALSE;
	isDirectory = attr & FILE_ATTRIBUTE_DIRECTORY;
	deletefunc = isDirectory ? RemoveDirectory : DeleteFile;

	//
	// �����N����t���p�X�ɂ���
	//
	_tcscpy(namebuf, _T("\\?\?\\"));
	if (!GetFullPathName(lpTargetName, sizeof(namebuf) / sizeof(namebuf[0]) - 4, namebuf + 4, NULL)) {
//		_ftprintf(stderr, _T("GetFullPathName failed (%d)\n"), GetLastError());
		return FALSE;
	}
//	_tprintf(_T("%s\n"), namebuf);
#ifdef UNICODE
	if (!lstrcpyn(u.iobuf.MountPointReparseBuffer.PathBuffer, namebuf, MAXIMUM_REPARSE_DATA_BUFFER_SIZE))
#else
	if (!MultiByteToWideChar(CP_ACP, 0, namebuf, -1,
			u.iobuf.MountPointReparseBuffer.PathBuffer, MAXIMUM_REPARSE_DATA_BUFFER_SIZE))
#endif
	{
//		_ftprintf(stderr, _T("MultiByteToWideChar failed (%d)\n"), GetLastError());
		return FALSE;
	}

	//
	// �����N�t�@�C�����쐬
	//
	if (isDirectory) {
		if (!CreateDirectory(lpLinkName, lpsa))
			return FALSE;
		hFile = CreateFile(lpLinkName, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
			OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	} else {
		hFile = CreateFile(lpLinkName, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, lpsa,
			CREATE_NEW, 0, NULL);
	}
	if (hFile == INVALID_HANDLE_VALUE) {
//		_ftprintf(stderr, _T("CreateFile failed (%d)\n"), GetLastError());
		return FALSE;
	}

	//
	// ���p�[�X�f�[�^��ݒ�
	//
	u.iobuf.ReparseTag = IO_REPARSE_TAG_MOUNT_POINT;
	u.iobuf.Reserved = 0;
	u.iobuf.MountPointReparseBuffer.SubstituteNameOffset = 0;
	u.iobuf.MountPointReparseBuffer.SubstituteNameLength = wcslen(u.iobuf.MountPointReparseBuffer.PathBuffer) * 2;
	u.iobuf.MountPointReparseBuffer.PrintNameOffset = u.iobuf.MountPointReparseBuffer.SubstituteNameLength + 2;
	u.iobuf.MountPointReparseBuffer.PrintNameLength = 0;
	memset((char *)u.iobuf.MountPointReparseBuffer.PathBuffer + 
		u.iobuf.MountPointReparseBuffer.SubstituteNameLength, 0, 4);
	u.iobuf.ReparseDataLength =
		8 +
		u.iobuf.MountPointReparseBuffer.PrintNameOffset +
		u.iobuf.MountPointReparseBuffer.PrintNameLength + 2;
	cb = 8 + u.iobuf.ReparseDataLength;
	if (!DeviceIoControl(hFile, FSCTL_SET_REPARSE_POINT,
					&u.iobuf, cb, NULL, 0, &cb, NULL)) {
//		_ftprintf(stderr, _T("DeviceIoControl failed (%d)\n"), GetLastError());
		CloseHandle(hFile);
		deletefunc(lpLinkName);
		return FALSE;
	}

	CloseHandle(hFile);
	return TRUE;
}

BOOL DumpReparsePoint(LPCTSTR lpFileName)
{
	HANDLE hFile = CreateFile(lpFileName, 0/*GENERIC_READ*/, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
		OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
//		OPEN_EXISTING, 0, NULL);
	BY_HANDLE_FILE_INFORMATION bhfi;
	DWORD size = 0;
	DWORD cb;
	char *p = NULL;
	if (hFile == INVALID_HANDLE_VALUE) {
		fprintf(stderr, "CreateFile failed (%d)\n", GetLastError());
	}
	GetFileInformationByHandle(hFile, &bhfi);
	printf("attr = %#08x\nlinks = %d\n", bhfi.dwFileAttributes, bhfi.nNumberOfLinks);
	printf("%d\n", size = GetFileSize(hFile, NULL));
#if 1
	if ((long)size > 0) {
		p = (char *)malloc(size + 1);
		if ((long)size > 0 && !ReadFile(hFile, p, size, &size, NULL)) {
			fprintf(stderr, "ReadFile failed (%d)\n", GetLastError());
			size = 0;
	//		return FALSE;
		}
		p[size] = 0;
		printf("%s", p);
		if (p) free(p);
	}
	CloseHandle(hFile);
	puts("using OS Handle");
#elif 0
	int fd = _open_osfhandle((long)hFile, O_BINARY | O_RDONLY);
	char *p = (char *)malloc(size + 1);
	read(fd, p, size);
	p[size] = 0;
	printf("%s", p);
	free(p);
	close(fd);
	puts("using CRT Handle");
#else
	int fd = _open_osfhandle((long)hFile, O_BINARY | O_RDONLY);
	FILE *fp = fdopen(fd, "rb");
	char *p = (char *)malloc(size + 1);
#if 1
	int c;
	while ((c = getc(fp)) != EOF) {
		printf("%c", c);
	}
	fflush(fp);
	puts("using getc");
#elif 1
	char buf[256];
	if (fp)
		while (fgets(buf, sizeof(buf), fp) != NULL) {
			printf("%s", buf);
		}
	}
	puts("using fgets");
#else
	fread(p, 1, size, fp);
	p[size] = 0;
	printf("%s", p);
	puts("using fread");
#endif
	free(p);
	if (fp)
		fclose(fp);
	puts("using file stream");
#endif
	hFile = CreateFile(lpFileName, 0/*GENERIC_WRITE*/, 0, NULL,
		OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		fprintf(stderr, "CreateFile failed (%d)\n", GetLastError());
		return FALSE;
	}
	if (!DeviceIoControl(hFile, FSCTL_GET_REPARSE_POINT,
					NULL, 0,
					&u.iobuf, 1024,
					&cb, NULL)) {
		fprintf(stderr, "DeviceIoControl failed (%d)\n", GetLastError());
		return FALSE;
	}
	DumpReparsePointBuf(cb);

	return TRUE;
}

int _tmain(int argc, TCHAR **argv)
{
	LPCTSTR target = NULL, link = NULL;
	int sflag = 0, jflag = 0;
	BOOL r;

	_tsetlocale(LC_ALL, _T(""));

	myname = argv[0];
	if (argc < 2) {
		_ftprintf(stderr, _T("usage: %s [-s|-j] <target> <linkname>\n"), argv[0]);
		return EXIT_FAILURE;
	}
	if (argc < 3) {
		DumpReparsePoint(argv[1]);
		return 0;
	}
	while (*++argv) {
		if (!_tcscmp(*argv, _T("-s"))) {
			sflag = 1;
		} else if (!_tcscmp(*argv, _T("-j"))) {
			jflag = 1;
		} else if (!target) {
			target = *argv;
		} else if (!link) {
			link = *argv;
		}
	}
	if (sflag) {
		r = CreateSymlink(link, target, NULL);
	} else if (jflag) {
		r = CreateJunction(link, target, NULL);
	} else {
		r = CreateHardLink(link, target, NULL);
	}
	if (!r) {
		PrintWin32Error(myname);
		return EXIT_FAILURE;
	}
	return 0;
}

